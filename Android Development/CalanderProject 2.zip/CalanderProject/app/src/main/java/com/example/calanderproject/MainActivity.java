package com.example.calanderproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView selectedDate = findViewById(R.id.textView1);
        CalendarView calendarView = findViewById(R.id.calander);
        Button reminder = findViewById(R.id.reminderbtn);

        reminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, MainActivityReminder.class);
                startActivity(i);
            }
        });

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int dayOfMonth) {

                if(month == 0) {
                    selectedDate.setText("Selected Date: " + dayOfMonth + " Month: Jan " + " Year: " + year);
                }
                if(month == 1) {
                    selectedDate.setText("Selected Date: " + dayOfMonth + " Month: Feb " + " Year: " + year);
                }
                if(month == 2) {
                    selectedDate.setText("Selected Date: " + dayOfMonth + " Month: March " + " Year: " + year);
                }
                if(month == 3) {
                    selectedDate.setText("Selected Date: " + dayOfMonth + " Month: April " + " Year: " + year);
                }
                if(month == 4) {
                    selectedDate.setText("Selected Date: " + dayOfMonth + " Month: May " + " Year: " + year);
                }if(month ==5) {
                    selectedDate.setText("Selected Date: " + dayOfMonth + " Month: June " + " Year: " + year);
                }if(month == 6) {
                    selectedDate.setText("Selected Date: " + dayOfMonth + " Month: July " + " Year: " + year);
                }if(month == 7) {
                    selectedDate.setText("Selected Date: " + dayOfMonth + " Month: Aug " + " Year: " + year);
                }if(month == 8) {
                    selectedDate.setText("Selected Date: " + dayOfMonth + " Month: Sep " + " Year: " + year);
                }if(month == 9) {
                    selectedDate.setText("Selected Date: " + dayOfMonth + " Month: Oct " + " Year: " + year);
                }if(month == 10) {
                    selectedDate.setText("Selected Date: " + dayOfMonth + " Month: Nov " + " Year: " + year);
                }if(month == 11) {
                    selectedDate.setText("Selected Date: " + dayOfMonth + " Month: Dec " + " Year: " + year);
                }

            }
        });

    }
}